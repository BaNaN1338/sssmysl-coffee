param(
    [string]$SourceImage = (Join-Path $PSScriptRoot 'art\icon-source.jpg'),
    [string]$AppMain = (Join-Path $PSScriptRoot 'app\src\main'),
    [string]$SiteIcon = (Join-Path (Split-Path -Parent $PSScriptRoot) 'icon-512.png')
)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing

if (-not (Test-Path -LiteralPath $SourceImage)) {
    throw "Icon source not found: $SourceImage"
}

$source = [System.Drawing.Image]::FromFile($SourceImage)
$densities = [ordered]@{
    'mdpi'    = 48
    'hdpi'    = 72
    'xhdpi'   = 96
    'xxhdpi'  = 144
    'xxxhdpi' = 192
}

function New-Canvas {
    param([int]$Size)
    $bitmap = New-Object System.Drawing.Bitmap($Size, $Size, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
    $graphics = [System.Drawing.Graphics]::FromImage($bitmap)
    $graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $graphics.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
    $graphics.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
    $graphics.CompositingQuality = [System.Drawing.Drawing2D.CompositingQuality]::HighQuality
    $graphics.Clear([System.Drawing.Color]::Transparent)
    return @($bitmap, $graphics)
}

function New-RoundedPath {
    param([int]$Size, [double]$RadiusRatio = 0.22)
    $radius = [Math]::Max(1.0, $Size * $RadiusRatio)
    $diameter = $radius * 2
    $path = New-Object System.Drawing.Drawing2D.GraphicsPath
    $path.AddArc(0, 0, $diameter, $diameter, 180, 90)
    $path.AddArc($Size - $diameter, 0, $diameter, $diameter, 270, 90)
    $path.AddArc($Size - $diameter, $Size - $diameter, $diameter, $diameter, 0, 90)
    $path.AddArc(0, $Size - $diameter, $diameter, $diameter, 90, 90)
    $path.CloseFigure()
    return $path
}

function Save-RoundedIcon {
    param(
        [int]$Size,
        [string]$Path,
        [double]$RadiusRatio = 0.22,
        [switch]$Circle
    )
    $pair = New-Canvas -Size $Size
    $bitmap = $pair[0]
    $graphics = $pair[1]
    try {
        if ($Circle) {
            $clip = New-Object System.Drawing.Drawing2D.GraphicsPath
            $clip.AddEllipse(0, 0, $Size, $Size)
        } else {
            $clip = New-RoundedPath -Size $Size -RadiusRatio $RadiusRatio
        }
        $graphics.SetClip($clip)
        $dest = New-Object System.Drawing.Rectangle(0, 0, $Size, $Size)
        $graphics.DrawImage($source, $dest, 0, 0, $source.Width, $source.Height, [System.Drawing.GraphicsUnit]::Pixel)
        $clip.Dispose()
        $bitmap.Save($Path, [System.Drawing.Imaging.ImageFormat]::Png)
    } finally {
        $graphics.Dispose()
        $bitmap.Dispose()
    }
}

function Save-AdaptiveForeground {
    param([int]$Size, [string]$Path)
    $pair = New-Canvas -Size $Size
    $bitmap = $pair[0]
    $graphics = $pair[1]
    try {
        # 108dp canvas, visible safe circle is 72dp. Keep the artwork
        # at 80% of the canvas so the calligraphy stays inside the mask.
        $imageSize = [int][Math]::Round($Size * 0.80)
        $offset = [int][Math]::Round(($Size - $imageSize) / 2)
        $clip = New-Object System.Drawing.Drawing2D.GraphicsPath
        $clip.AddEllipse($offset, $offset, $imageSize, $imageSize)
        $graphics.SetClip($clip)
        $dest = New-Object System.Drawing.Rectangle($offset, $offset, $imageSize, $imageSize)
        $graphics.DrawImage($source, $dest, 0, 0, $source.Width, $source.Height, [System.Drawing.GraphicsUnit]::Pixel)
        $clip.Dispose()
        $bitmap.Save($Path, [System.Drawing.Imaging.ImageFormat]::Png)
    } finally {
        $graphics.Dispose()
        $bitmap.Dispose()
    }
}

foreach ($entry in $densities.GetEnumerator()) {
    $density = $entry.Key
    $size = [int]$entry.Value
    $dir = Join-Path $AppMain "res\mipmap-$density"
    New-Item -ItemType Directory -Force -Path $dir | Out-Null

    Save-RoundedIcon -Size $size -Path (Join-Path $dir 'ic_launcher.png')
    Save-RoundedIcon -Size $size -Path (Join-Path $dir 'ic_launcher_round.png') -Circle
    Save-AdaptiveForeground -Size ([int]($size * 2.25)) -Path (Join-Path $dir 'ic_launcher_foreground.png')
}

# PWA / store icon
$storePair = New-Canvas -Size 512
$storeBitmap = $storePair[0]
$storeGraphics = $storePair[1]
try {
    $storeGraphics.DrawImage($source, (New-Object System.Drawing.Rectangle(0, 0, 512, 512)), 0, 0, $source.Width, $source.Height, [System.Drawing.GraphicsUnit]::Pixel)
    $storeBitmap.Save($SiteIcon, [System.Drawing.Imaging.ImageFormat]::Png)
} finally {
    $storeGraphics.Dispose()
    $storeBitmap.Dispose()
}

$source.Dispose()
Write-Output "Icons generated from: $SourceImage"
Write-Output "Android launcher icons: $AppMain\res\mipmap-*"
Write-Output "Site icon: $SiteIcon"
