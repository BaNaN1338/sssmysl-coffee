param(
    [string]$OutputApk = (Join-Path (Split-Path -Parent $PSScriptRoot) 'smysl.apk'),
    [string]$KeystorePath = ''
)

$ErrorActionPreference = 'Stop'

$ProjectRoot = $PSScriptRoot
$RepoRoot = Split-Path -Parent $ProjectRoot
$AppMain = Join-Path $ProjectRoot 'app\src\main'
$Jdk = 'C:\Users\art52\AppData\Local\Programs\Microsoft\jdk-17.0.14.7-hotspot'
$AndroidSdk = 'C:\Users\art52\AppData\Local\Android\Sdk'
$BuildTools = Join-Path $AndroidSdk 'build-tools\35.0.0'
$AndroidJar = Join-Path $AndroidSdk 'platforms\android-35\android.jar'
$Work = Join-Path $env:TEMP 'opencode\smysl-android-build'
$Password = 'SmyslCoffee2026!'
$Alias = 'smysl'

if (-not (Test-Path -LiteralPath $Jdk)) { throw "JDK not found: $Jdk" }
if (-not (Test-Path -LiteralPath $AndroidJar)) { throw "Android platform not found: $AndroidJar" }
if (-not (Test-Path -LiteralPath (Join-Path $BuildTools 'aapt2.exe'))) { throw "Android build-tools not found: $BuildTools" }

if ([string]::IsNullOrWhiteSpace($KeystorePath)) {
    $Desktop = [Environment]::GetFolderPath('Desktop')
    $SigningDir = Join-Path $Desktop 'SmyslAndroid'
    $KeystorePath = Join-Path $SigningDir 'smysl-release.jks'
} else {
    $SigningDir = Split-Path -Parent $KeystorePath
}
New-Item -ItemType Directory -Force -Path $SigningDir | Out-Null

$Keytool = Join-Path $Jdk 'bin\keytool.exe'
if (-not (Test-Path -LiteralPath $KeystorePath)) {
    & $Keytool -genkeypair -v `
        -keystore $KeystorePath `
        -alias $Alias `
        -keyalg RSA `
        -keysize 2048 `
        -validity 10000 `
        -storepass $Password `
        -keypass $Password `
        -dname "CN=Smysl Coffee, OU=Mobile, O=Smysl Coffee, L=Smysl, C=RU"
    if ($LASTEXITCODE -ne 0) { throw 'keytool failed' }

    @(
        "alias=$Alias",
        "storePassword=$Password",
        "keyPassword=$Password",
        "created=$(Get-Date -Format o)"
    ) | Set-Content -LiteralPath (Join-Path $SigningDir 'keystore-info.txt') -Encoding UTF8
}

if (Test-Path -LiteralPath $Work) { Remove-Item -Recurse -Force $Work }
New-Item -ItemType Directory -Force -Path $Work | Out-Null

Copy-Item -LiteralPath $AppMain -Destination (Join-Path $Work 'main') -Recurse
$MainCopy = Join-Path $Work 'main'
$GenDir = Join-Path $Work 'gen'
$ClassesDir = Join-Path $Work 'classes'
$DexDir = Join-Path $Work 'dex'
New-Item -ItemType Directory -Force -Path $GenDir, $ClassesDir, $DexDir | Out-Null

$env:JAVA_HOME = $Jdk
$Aapt2 = Join-Path $BuildTools 'aapt2.exe'
$Javac = Join-Path $Jdk 'bin\javac.exe'

Write-Host '1/6 Compiling resources...'
& $Aapt2 compile --dir (Join-Path $MainCopy 'res') -o (Join-Path $Work 'res.zip')
if ($LASTEXITCODE -ne 0) { throw 'aapt2 compile failed' }

Write-Host '2/6 Linking resources...'
& $Aapt2 link `
    -o (Join-Path $Work 'base.apk') `
    -I $AndroidJar `
    --manifest (Join-Path $MainCopy 'AndroidManifest.xml') `
    -R (Join-Path $Work 'res.zip') `
    --java $GenDir `
    --auto-add-overlay `
    --min-sdk-version 24 `
    --target-sdk-version 34
if ($LASTEXITCODE -ne 0) { throw 'aapt2 link failed' }

Write-Host '3/6 Compiling Java...'
$JavaFiles = @()
$JavaFiles += (Get-ChildItem (Join-Path $MainCopy 'java') -Recurse -Filter *.java).FullName
$JavaFiles += (Get-ChildItem $GenDir -Recurse -Filter *.java).FullName
& $Javac -encoding UTF-8 -source 8 -target 8 -Xlint:-options `
    -bootclasspath "$AndroidJar;$BuildTools\core-lambda-stubs.jar" `
    -d $ClassesDir `
    $JavaFiles
if ($LASTEXITCODE -ne 0) { throw 'javac failed' }

Write-Host '4/6 Building classes.dex...'
$ClassFiles = (Get-ChildItem $ClassesDir -Recurse -Filter *.class).FullName
& (Join-Path $BuildTools 'd8.bat') --lib $AndroidJar --min-api 24 --output $DexDir $ClassFiles
if ($LASTEXITCODE -ne 0) { throw 'd8 failed' }

Write-Host '5/6 Packaging and aligning...'
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$UnsignedApk = Join-Path $Work 'unsigned.apk'
Copy-Item -LiteralPath (Join-Path $Work 'base.apk') -Destination $UnsignedApk
$zip = [System.IO.Compression.ZipFile]::Open($UnsignedApk, [System.IO.Compression.ZipArchiveMode]::Update)
try {
    [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile(
        $zip,
        (Join-Path $DexDir 'classes.dex'),
        'classes.dex',
        [System.IO.Compression.CompressionLevel]::Optimal
    ) | Out-Null
} finally {
    $zip.Dispose()
}
& (Join-Path $BuildTools 'zipalign.exe') -f 4 $UnsignedApk (Join-Path $Work 'aligned.apk')
if ($LASTEXITCODE -ne 0) { throw 'zipalign failed' }

Write-Host '6/6 Signing...'
& (Join-Path $BuildTools 'apksigner.bat') sign `
    --ks $KeystorePath `
    --ks-key-alias $Alias `
    --ks-pass "pass:$Password" `
    --key-pass "pass:$Password" `
    --out $OutputApk `
    (Join-Path $Work 'aligned.apk')
if ($LASTEXITCODE -ne 0) { throw 'apksigner sign failed' }

& (Join-Path $BuildTools 'apksigner.bat') verify --verbose $OutputApk
if ($LASTEXITCODE -ne 0) { throw 'apksigner verify failed' }

$apk = Get-Item -LiteralPath $OutputApk
Write-Host ''
Write-Host "APK: $($apk.FullName)"
Write-Host "Size: $([Math]::Round($apk.Length / 1MB, 2)) MB"
Write-Host "Keystore: $KeystorePath"
