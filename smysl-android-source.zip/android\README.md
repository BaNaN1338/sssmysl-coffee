# Приложение «Смысл» для Android

Нативная WebView-обёртка вокруг сайта:

`https://banan1338.github.io/sssmysl-coffee/?app=android`

## Что умеет

- открывает актуальную версию сайта, поэтому меню, сторис и настройки обновляются без переустановки приложения;
- сохраняет cookies и localStorage (вход владельца, корзина, настройки);
- поддерживает выбор фото для сторис из галереи;
- открывает Telegram, карты и внешние ссылки в браузере/приложениях;
- показывает брендированный экран «Нет подключения» с кнопкой повтора;
- кнопка «Назад» листает историю WebView, двойное нажатие закрывает приложение;
- иконка приложения и PWA-иконка собраны из `art/icon-source.jpg`.

## Сборка APK

Требуются JDK 17 и Android SDK:

- build-tools `35.0.0`
- platforms `android-35`

Запуск:

```powershell
powershell -ExecutionPolicy Bypass -File .\build-apk.ps1
```

Готовый файл по умолчанию: `..\smysl.apk` в корне репозитория.

Ключ подписи создаётся один раз в папке `SmyslAndroid` на рабочем столе.
Там же лежит `keystore-info.txt` с alias и паролями. **Не публикуйте эту папку.**
Для выпуска обновлений APK нужно подписывать тем же ключом.

## Иконки

```powershell
powershell -ExecutionPolicy Bypass -File .\generate-icons.ps1
```

Скрипт создаёт launcher-иконки для всех плотностей, adaptive foreground,
round-иконку и `../icon-512.png` для PWA.
