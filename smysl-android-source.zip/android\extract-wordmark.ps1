param(
    [string]$SourceImage = (Join-Path $PSScriptRoot 'art\icon-source.jpg'),
    [string]$OutputImage = (Join-Path (Split-Path -Parent $PSScriptRoot) 'smysl-wordmark.png'),
    [string]$DarkOutputImage = (Join-Path (Split-Path -Parent $PSScriptRoot) 'smysl-wordmark-dark.png')
)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing

$code = @'
using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;

public static class SmyslWordmark
{
    public static void Extract(string sourcePath, string outputPath, int cropX, int cropY, int cropWidth, int cropHeight, byte colorR, byte colorG, byte colorB)
    {
        using (var source = new Bitmap(sourcePath))
        {
            int width = cropWidth;
            int height = cropHeight;
            var rgba = new byte[width * height * 4];

            int minX = width, minY = height, maxX = -1, maxY = -1;

            for (int y = 0; y < height; y++)
            {
                for (int x = 0; x < width; x++)
                {
                    Color c = source.GetPixel(cropX + x, cropY + y);
                    int alpha = 0;

                    if (c.R >= 190 && c.G >= 180)
                    {
                        double score = (c.B - 165.0) / 40.0;
                        if (c.B >= 205 && c.R >= 225 && c.G >= 215) score = 1.0;
                        score = Math.Max(0.0, Math.Min(1.0, score));
                        alpha = score < 0.5 ? 0 : (int)Math.Round(((score - 0.5) / 0.5) * 255.0);
                    }

                    int index = (y * width + x) * 4;
                    rgba[index] = colorB;
                    rgba[index + 1] = colorG;
                    rgba[index + 2] = colorR;
                    rgba[index + 3] = (byte)alpha;

                    if (alpha > 80)
                    {
                        if (x < minX) minX = x;
                        if (y < minY) minY = y;
                        if (x > maxX) maxX = x;
                        if (y > maxY) maxY = y;
                    }
                }
            }

            if (maxX < minX || maxY < minY)
            {
                throw new InvalidOperationException("Wordmark not found in source image");
            }

            int padding = 24;
            minX = Math.Max(0, minX - padding);
            minY = Math.Max(0, minY - padding);
            maxX = Math.Min(width - 1, maxX + padding);
            maxY = Math.Min(height - 1, maxY + padding);

            int outWidth = maxX - minX + 1;
            int outHeight = maxY - minY + 1;

            using (var output = new Bitmap(outWidth, outHeight, PixelFormat.Format32bppArgb))
            {
                var data = output.LockBits(new Rectangle(0, 0, outWidth, outHeight), ImageLockMode.WriteOnly, PixelFormat.Format32bppArgb);
                try
                {
                    var row = new byte[outWidth * 4];
                    for (int y = 0; y < outHeight; y++)
                    {
                        Array.Copy(rgba, ((minY + y) * width + minX) * 4, row, 0, outWidth * 4);
                        Marshal.Copy(row, 0, IntPtr.Add(data.Scan0, y * data.Stride), outWidth * 4);
                    }
                }
                finally
                {
                    output.UnlockBits(data);
                }

                output.Save(outputPath, ImageFormat.Png);
                Console.WriteLine("Wordmark: " + outWidth + "x" + outHeight);
            }
        }
    }
}
'@

Add-Type -TypeDefinition $code -ReferencedAssemblies System.Drawing

[SmyslWordmark]::Extract($SourceImage, $OutputImage, 90, 550, 1930, 760, 246, 244, 232)
[SmyslWordmark]::Extract($SourceImage, $DarkOutputImage, 90, 550, 1930, 760, 37, 46, 19)
Write-Output $OutputImage
Write-Output $DarkOutputImage
